package br.com.alura.servidor;

import java.io.PrintStream;

public class ComandoC2 implements Runnable {

	private PrintStream saida;

	public ComandoC2(PrintStream saida) {
		this.saida = saida;
	}

	@Override
	public void run() {
		// será descarregado no console do servidor
		System.out.println("Executando o comando c2");

		try {
			Thread.sleep(5000); // simulando operação demorada
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
		
		//throw new RuntimeException("Problema no comando C2...");
		
		// mensagem que será enviada ao cliente
		saida.println("Comando c2 executado com sucesso!");

	}

}
