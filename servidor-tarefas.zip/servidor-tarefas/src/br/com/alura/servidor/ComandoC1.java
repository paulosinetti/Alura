package br.com.alura.servidor;

import java.io.PrintStream;

public class ComandoC1 implements Runnable {

	private PrintStream saida; // atributo representa a saída do cliente

	public ComandoC1(PrintStream saida) {
		this.saida = saida;
	}

	@Override
	public void run() {
		// será descarregado no console do servidor
		System.out.println("Executando o comando c1");
		
		try {
			Thread.sleep(20000); // simulando operação demorada Ex: acesso ao banco de dados, etc...
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
		
		// mensagem que será enviada ao cliente
		saida.println("Comando c1 executado com sucesso!");

	}

}
