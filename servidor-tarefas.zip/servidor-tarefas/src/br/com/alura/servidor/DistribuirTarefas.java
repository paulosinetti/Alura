package br.com.alura.servidor;

import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class DistribuirTarefas implements Runnable {

	private Socket socket;
	private ServidorTarefas servidor;
	private ExecutorService threadPool;
	private BlockingQueue<String> filaComandos;

	public DistribuirTarefas(ExecutorService threadPool, BlockingQueue<String> filaComandos, Socket socket, ServidorTarefas servidor) {
		this.threadPool = threadPool;
		this.socket = socket;
		this.servidor = servidor;
		this.filaComandos = filaComandos;
		
	}

	@Override
	public void run() {
		System.out.println("Distribuindo as tarefas para o cliente: " + socket);

		try {
			// recebe os dados enviados pelo cliente
			Scanner entradaCliente = new Scanner(socket.getInputStream());
			
			
			// envia os dados de retorno ao cliente
			PrintStream saidaCliente = new PrintStream(socket.getOutputStream());

			while (entradaCliente.hasNextLine()) {
				String comando = entradaCliente.nextLine();
				System.out.println("Comando recebido do cliente: " + comando);
				
				switch (comando) {
                case "c1": {
                    // confirmação ao cliente
                    saidaCliente.println("Confirmação do comando c1");
                    ComandoC1 c1 = new ComandoC1(saidaCliente);
                    this.threadPool.execute(c1);
                    
                    break;
                }
                case "c2": {
                    saidaCliente.println("Confirmação do comando c2");
                    //ComandoC2 c2 = new ComandoC2(saidaCliente);
                    //this.threadPool.execute(c2);
                    ComandoC2ChamaWS c2WS = new ComandoC2ChamaWS(saidaCliente);
                    ComandoC2AcessaBanco c2Banco = new ComandoC2AcessaBanco(saidaCliente);
                    
                    Future<String> futureWS = this.threadPool.submit(c2WS);
                    Future<String> futureBanco = this.threadPool.submit(c2Banco);
                    JuntaResultadosFutureWSFutureBanco juntaResultados = new JuntaResultadosFutureWSFutureBanco(futureWS, futureBanco, saidaCliente);
                    this.threadPool.submit(juntaResultados);
                    
                    break;
                }
                
                case "c3": {
                	
                	this.filaComandos.put(comando); // lembrando, bloqueia se estiver cheia
                	saidaCliente.println("Comando c3 adicionado na fila");
                	break;
                }
                
                case "fim": {
                    saidaCliente.println("Comandado desligamento do servidor");
                    servidor.parar();
                    return;
                }
                default: {
                    saidaCliente.println("Comando não encontrado");
                }
            }

				System.out.println(comando);
				
			}
			saidaCliente.close();
			entradaCliente.close();
			System.out.println("Encerrando a requisição ");

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

}
