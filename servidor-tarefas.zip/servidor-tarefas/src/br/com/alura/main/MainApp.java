package br.com.alura.main;

import java.io.IOException;

import br.com.alura.servidor.ServidorTarefas;

public class MainApp {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		ServidorTarefas servidorTarefas = new ServidorTarefas();
		servidorTarefas.rodar();
	}

}
