package br.com.alura.cliente;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public class ClienteTarefas {

	public static void main(String[] args) throws Exception {
		final Socket socket = new Socket("localhost", 12345);
		System.out.println("Conexão com o server estabelecida");

		Thread threadEnviaComando = new Thread(new Runnable() {

			@Override
			public void run() {

				try {
					System.out.println("Pode enviar comandos!");

					// saida baseado no OutputStream
					PrintStream saida = new PrintStream(
							socket.getOutputStream());

					// estabelecendo a leitura do teclado
					Scanner teclado = new Scanner(System.in);

					// aguardando <enter> do teclado
					while (teclado.hasNextLine()) {

						// pegando o que foi digitado no console
						String linha = teclado.nextLine();

						// se for vazio não vamos enviar nada para o servidor
						
						if("".equals(linha.trim())){
							break;
						}
						/*if (linha.trim().equals("")) {
							break;
						}*/

						// enviado para o servidor
						saida.println(linha);
					}

					saida.close();
					teclado.close();
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
		}, "Thread-Envia-Comando");
		
		// instanciando classe anônima
		Thread threadRecebeResposta = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					System.out.println("Recebendo dados do servidor");

					// leitura dos dados que vem do servidor
					Scanner respostaServidor = new Scanner(
							socket.getInputStream());

					while (respostaServidor.hasNextLine()) {
						String linha = respostaServidor.nextLine();
						System.out.println(linha);
					}

					respostaServidor.close();
				} catch (IOException e) {
					throw new RuntimeException(e);
				}

			}
		}, "Thread-Recebe-Resposta");


		// fechando os recursos
		// ctrl + shift + i = inspect no debug
		threadEnviaComando.start();
		threadRecebeResposta.start();
		// a thread Main só pode ser encerrada quando a threadEnviaComando tiver encerrado seu método run()
		threadEnviaComando.join();
		socket.close();

	}

}
